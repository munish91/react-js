import Resturant from "./component/Basics/Resturant";


const App = () => {
       
       return <Resturant />
}

export default App
